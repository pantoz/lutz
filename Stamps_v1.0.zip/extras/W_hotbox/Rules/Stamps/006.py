#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Refresh Stamps
# COLOR: #000000
#
#----------------------------------------------------------------------------------------------------------

import stamps;stamps.refreshStamps(nuke.selectedNodes())