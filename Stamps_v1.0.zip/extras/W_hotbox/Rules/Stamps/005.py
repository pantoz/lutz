#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Rename Tag
# COLOR: #000000
#
#----------------------------------------------------------------------------------------------------------

import stamps;stamps.renameTag(nuke.selectedNodes())